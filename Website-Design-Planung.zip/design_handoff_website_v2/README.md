# Handoff: marcsandmann.github.io — Version 2

## Überblick

Persönliche Archiv-Website von Marc Sandmann. Sie sammelt Hausarbeiten und
Seminararbeiten („Themen (Auswahl)"), Vortragsfolien („Präsentationen"),
kürzere Texte („Freie Essays") sowie den beruflichen Werdegang
(„Stationen") und bietet eine Kontaktseite.

Die bestehende Seite liegt als statisches GitHub-Pages-Projekt vor
(`marcsandmann.github.io`) und verwendet bereits `styles.css` (Designsystem
„Modernist"), `site.css` (Seitenlayout) und `newspaper.css` (Essay-Layout).
Diese Übergabe beschreibt **Version 2**: geänderte Navigation, neues
Farbkonzept mit einer zweiten Farbe, Porträtfoto, ausgebaute Texte,
gruppierte Themenliste, eigene Stationen-Seite und eine neue Detailseite
für einzelne Arbeiten.

## Über die Design-Dateien

Die Dateien in diesem Paket sind **Design-Referenzen in HTML** — ein
Prototyp, der Aussehen und Verhalten zeigt, kein produktiver Code zum
direkten Kopieren.

`Website-Umsetzung v2.dc.html` ist eine **Übersichts-Leinwand**: sie zeigt
alle acht Seiten der Website untereinander, jede in einem Rahmen
(`.page-shell`) mit einer roten Nummer und einer kurzen Notiz darüber.
Diese Nummernschilder, die Notizen und die äußere `<section>` mit dem
grauen Hintergrund (`#dcdada`) gehören **nicht** zur Website — sie sind
nur Präsentationsrahmen. Zu implementieren ist der Inhalt **innerhalb**
jeder `.page-shell`, jeweils als eigene HTML-Seite.

Die Datei ist außerdem ein „Design Component"-Prototyp: Listen werden über
`<sc-for>`-Schleifen aus JavaScript-Daten gerendert (`GROUPS`,
`STATION_GROUPS` am Ende der Datei) und `{{ … }}` sind Platzhalter. In der
echten Seite können diese Listen als statisches HTML oder aus einer
Datendatei erzeugt werden — das bestehende Projekt nutzt dafür bereits
`presentations-data.js` und Markdown-Dateien im Ordner `essays/`.

Die Umsetzung soll im vorhandenen statischen HTML/CSS-Setup des Repos
erfolgen, mit den bestehenden Stylesheets. Kein Framework nötig.

## Fidelity

**High-fidelity.** Farben, Typografie, Abstände und Rahmen sind final und
sollen genau übernommen werden. Alle Werte stammen aus dem Designsystem
(CSS-Variablen in `styles.css`); die einzigen Literalwerte sind die neue
Zweitfarbe (siehe Design Tokens).

Ausnahme: alle Essay-Inhalte und der Abstract auf der Detailseite sind
ausdrücklich Platzhaltertext. Ebenso fehlen die Untertitel zu 17 der 18
Themen — nur „Lessing" hat einen.

---

## Navigation (auf allen Seiten gleich)

`nav.nav` mit `padding: var(--space-4) var(--space-8)`, unten 2px Trennlinie.

- Marke links: `span.nav-brand` — „Marc Sandmann"
- Links rechts, in dieser Reihenfolge:
  `Themen (Auswahl)` · `Präsentationen` · `Essays` · `Stationen` · `Kontakt`
- Die aktive Seite trägt `aria-current="page"`.

Geändert gegenüber Version 1: „Hausarbeiten" → „Themen (Auswahl)",
„Werdegang" → „Stationen".

Fußzeile auf allen Seiten: `footer.site-footer.text-muted` mit
`border-top-color: #2a4b8d`, Text „© 2026 Marc Sandmann".

---

## Screens

### 1. Startseite (`index.html`)

**Zweck:** Einstieg, Kurzvorstellung, Verteiler in die drei Sammlungen.

**Hero** — CSS-Grid, `grid-template-columns: 1.5fr 1fr`, unten 2px Trennlinie.

*Linke Spalte* (`padding: var(--space-8)`, rechts 2px Trennlinie, Flex-Spalte,
`justify-content: space-between`, `gap: var(--space-6)`):

- Kicker `h6`, `color: #2a4b8d`, `margin: 0 0 var(--space-3)` — „Öffentliches Archiv"
- `h1`, `font-size: clamp(28px, 3.6vw, 46px)`, `line-height: 1.02`,
  `max-width: 26ch` — „Hier sammle ich meine Themen und stelle sie
  Kommiliton:innen, Dozierenden und Freund:innen zur Verfügung."
- Absatz, `font-size: 17px`, `max-width: 58ch` — „Diese Seite sammelt, woran
  ich in Studium und Beruf gearbeitet habe: Hausarbeiten aus Soziologie,
  Kunstgeschichte, Germanistik und Geschichte, Folien aus Uni und Job sowie
  kürzere Essays zu Themen, die gerade auf dem Tisch liegen."
- Zwei Buttons nebeneinander, `gap: var(--space-3)`:
  `.btn.btn-primary` „Themen ansehen" → Themenseite,
  `.btn.btn-secondary` „Essays lesen" → Essay-Übersicht

*Rechte Spalte* (Flex-Spalte):

- Porträtfoto, `flex: 1; min-height: 380px; overflow: hidden`;
  `img` mit `width/height: 100%`, `object-fit: cover`,
  `object-position: 50% 22%`. **In Farbe** — bewusst ohne die
  `.grayscale`-Klasse des Designsystems.
- Darunter Biografie-Block: `padding: var(--space-6) var(--space-8)`,
  `border-top: 2px solid var(--color-divider)`, `background: #e4e9f4`.
  `h6` „Marc Sandmann" + Absatz `font-size: 14px`, `line-height: 1.5`:
  „B.A. Wirtschaftspsychologie, abgeschlossen. Studium der Soziologie und
  Kunstgeschichte (Hauptfächer) sowie Germanistik und Geschichte
  (Nebenfächer) an der Universität Hamburg, laufend."

**Verteiler** — `section.distributor`, drei gleich breite Spalten
(`.distributor-col`, je `padding: var(--space-8)`, 2px Trennlinie rechts,
`gap: var(--space-4)`). Jede Spalte:

- Kopf `.distributor-col-head` mit `border-bottom: 3px solid #2a4b8d`,
  `padding-bottom: var(--space-2)`: `h3` links, Zähler rechts (`.text-muted`)
- Beschreibungsabsatz, `font-size: 14px`, `.text-muted`
- `.entry-list` mit bis zu drei `.entry`-Links (Titel fett, darunter
  `.entry-meta` in 13px)
- `.btn.btn-ghost`, `align-self: flex-start`

Inhalte:

| Spalte | Zähler | Beschreibung | Vorschau-Einträge | Button |
|---|---|---|---|---|
| Themen (Auswahl) | 18 | „Hausarbeiten, Forschungsprojekte und die Bachelorarbeit — nach Fächern geordnet, jeweils mit Abstract und PDF." | „Empirische Untersuchung zu Luhmanns Konzept der brauchbaren Illegalität" (Bachelorarbeit · Soziologie); „Der Baum des Lebens in mittelalterlichen Kreuzdarstellungen" (Kunstgeschichte); „Lessing" (Lessings Lustspiel „Die Juden" · Germanistik) | Alle Themen |
| Präsentationen | in Arbeit | „Folien aus Seminaren, Kolloquien und dem Beruf. Jede Datei steht als PDF zum Download, mit Anlass und Datum." | Hinweistext „Der Bereich wird gerade gefüllt. Die ersten Folien folgen im Herbst." | Zum Downloadbereich |
| Freie Essays | 2 | „Kürzere Texte außerhalb des Seminarbetriebs — zu Lektüren, Ausstellungen und Beobachtungen aus der Arbeit." | zwei Platzhalter-Essays mit Datum | Alle Essays |

**Stationen-Kurzraster** — Grid `220px 1fr`, unten 2px Trennlinie.
Links `h6` „Stationen" + `.text-muted` 13px „Redaktion, Beratung, Archiv und
Zivilgesellschaft". Rechts vierspaltiges Raster, jede Zelle
`padding: var(--space-6) var(--space-8)`, 1px Linien rechts und unten,
Flex-Spalte mit `gap: 4px`: Name (Heading-Font, 800, 15px) und darunter das
Jahr in `#2a4b8d`, 13px. Reihenfolge und Daten wie unter „Stationen".

**Kontaktbanner** — `section.contact-banner`: roter Vollton
(`var(--color-accent)`), Text in `var(--color-bg)`,
`padding: var(--space-8)`, Flex, `align-items: flex-end`,
`justify-content: space-between`. `h2` „Schreib mir unter", rechts der
E-Mail-Link `info.marcsandmann@gmail.com` (Heading-Font, 800, 16px,
2px Unterstrich in `var(--color-bg)`).

---

### 2. Themen (Auswahl) (`themen.html`)

**Kopf** — `.register-header`, Grid `2fr 1fr`:

- `.register-intro`: `h1` „Themen (Auswahl)"; Absatz: „Eine Auswahl der
  Fragen, mit denen ich mich im Studium beschäftigt habe — von der
  Organisationssoziologie über die Bildgeschichte des Mittelalters bis zur
  Hamburger Arbeitergeschichte. Jeder Eintrag führt zu einer kurzen
  Zusammenfassung und der Arbeit als PDF."
- `.register-stats` mit `background: #e4e9f4`: „Einträge 18", „Fächer 5"

**Fachgruppen** — pro Gruppe eine `section` mit 2px Trennlinie unten:

- Gruppenkopf: `padding: var(--space-4) var(--space-8)`,
  `background: #e4e9f4`, `border-bottom: 1px solid var(--color-divider)`,
  Flex mit `align-items: baseline; gap: var(--space-3)`.
  `h3` in `#2a4b8d`, 20px; daneben Notiz `.text-muted` 13px.
- Einträge: `padding: 0 var(--space-8) var(--space-4)`, darin `.entry`-Links
  als Flex mit `justify-content: space-between`, `gap: var(--space-6)`.
  Links Titel und — falls vorhanden — Untertitel als `.entry-meta`.
  Rechts ein Tag: `background: transparent; border: 1px solid #2a4b8d;
  color: #2a4b8d`.
  Jeder Eintrag verlinkt auf die Detailseite.

Gruppen und Einträge (Reihenfolge exakt so):

**Soziologie** — „Organisation, Medien, Märkte"
1. Empirische Untersuchung zu Luhmanns Konzept der brauchbaren Illegalität — Untertitel „Bachelorarbeit" — Tag: Abschlussarbeit
2. Luhmanns Theorie der Massenmedien — Tag: Hausarbeit
3. Prozessabläufe in Organisationen — Tag: Hausarbeit
4. Entwicklungswege von Jugendlichen in zivilgesellschaftlicher Projektarbeit — Tag: Forschungsprojekt
5. Kommunikationscodes von Blumen — Tag: Hausarbeit

**Kunstgeschichte** — „Bildgeschichte und Druckgrafik"
1. Dürers Druckgrafiken — Hausarbeit
2. Dürers Aquarelle der ersten Italienreise — Hausarbeit
3. Der Baum des Lebens in mittelalterlichen Kreuzdarstellungen — Hausarbeit

**Germanistik** — „Aufklärung und Dramatik"
1. Lessing — Untertitel „Lessings Lustspiel „Die Juden"" — Hausarbeit

**Geschichte** — „Hamburg im 19. Jahrhundert, Antike"
1. Der Aufstand der Hamburger Hafenarbeiter von 1896 — Hausarbeit
2. Schulreform in Hamburg zwischen 1871 und 1914 — Hausarbeit
3. Distinktionsmerkmale im alten Rom — Hausarbeit

**Wirtschaftspsychologie und Methoden** — „Diagnostik, Empirie, Markt"
1. Psychologische Diagnostik und IQ — Hausarbeit
2. Skaleneinsatz in quantitativer Forschung — Hausarbeit
3. Forschungsprojekt zu Persönlichkeit und Berufswahl — Forschungsprojekt
4. Markt- und Konsumforschung — Hausarbeit
5. Winner-Take-All-Märkte — Hausarbeit
6. Spieltheorie — Hausarbeit

> Hinweis: Die Fachzuordnung wurde aus den Titeln abgeleitet und ist noch
> nicht vom Autor bestätigt. Untertitel liefert er nach.

**Fuß** — `.register-footer`: links `.text-muted` „Ältere Arbeiten auf
Anfrage.", rechts `.btn.btn-primary` „Zur Startseite".

---

### 3. Thema — Detailseite (Muster für alle 18 Einträge)

**Kopf** — Grid `1.6fr 1fr`, unten 2px Trennlinie.

*Links* (`padding: var(--space-8)`, 2px Trennlinie rechts):
zwei Tags nebeneinander (`gap: var(--space-2)`, gleicher blauer Outline-Stil
wie in der Liste) — Fach und Art; `h1`
`font-size: clamp(28px, 4vw, 48px)`, `line-height: 1.05`, `max-width: 18ch`;
darunter der Untertitel als Absatz in 19px, `max-width: 44ch`.

*Rechts* (`padding: var(--space-8)`, `background: #e4e9f4`, Flex-Spalte,
`justify-content: space-between`): Metadatenliste mit je Label
(`.text-muted`) links und Wert rechts, 14px, 1px Trennlinien
(letzte Zeile ohne):

- Fach — Germanistik
- Art — Seminararbeit
- Hochschule — Universität Hamburg

Darunter `.btn.btn-primary` **„Abstract herunterladen"**.

**Abstract** — Grid `220px 1fr`, unten 2px Trennlinie. Links `h6`
„Abstract". Rechts zwei Absätze, `max-width: 68ch`, erster 17px
`line-height: 1.6`, zweiter `.text-muted` 15px. Beide sind Platzhalter.

**Fuß** — `.register-footer`: links `.btn.btn-ghost` „← Zurück zu den
Themen", rechts `.btn.btn-primary` „Abstract herunterladen".

---

### 4. Präsentationen (`praesentationen.html`)

**Kopf** — `.register-header`: `h1` „Präsentationen"; Absatz: „Folien aus
Seminaren, Kolloquien und dem Berufsalltag. Wo es sinnvoll ist, liegt neben
der Datei eine kurze Notiz zum Anlass — damit die Folien auch ohne den
gesprochenen Teil lesbar bleiben." Kennzahlen (`background: #e4e9f4`):
„Einträge 0", „Format PDF".

**Leerzustand** — `padding: var(--space-8)`, Grid `1fr 1fr`,
`gap: var(--space-8)`, `align-items: start`, unten 2px Trennlinie:

- Links `h3` „Der Bereich wird gerade aufgebaut." und Absatz 15px,
  `max-width: 46ch`: „Die ersten Vorträge aus dem Studium werden derzeit für
  die Veröffentlichung durchgesehen. Wenn du eine bestimmte Präsentation
  suchst, frag sie gern direkt an."
- Rechts Kasten: `background: #e4e9f4`, `padding: var(--space-6)`,
  `border-left: 4px solid #2a4b8d`, Flex-Spalte `gap: var(--space-3)`.
  `h6` „Was hier erscheinen wird" und drei Zeilen à 14px:
  „Seminarvorträge aus Soziologie und Kunstgeschichte",
  „Ergebnispräsentationen aus Forschungsprojekten",
  „Folien aus der Beratungs- und Redaktionsarbeit".

Sobald Dateien vorhanden sind, greift das bestehende `.download-grid` /
`.download-card`-Muster aus `site.css` (zwei Spalten).

---

### 5. Freie Essays — Übersicht (`essays.html`)

Nutzt `newspaper.css` unverändert.

- `header.hero.newspaper-masthead`: `h6.text-muted` „Freie Essays"; `h1`
  „Kürzere Texte zu Themen, die mich gerade beschäftigen."; Absatz „Nicht
  für einen Schein geschrieben, sondern weil die Frage offen geblieben ist.
  Erscheint unregelmäßig."
- `section.teaser-grid` mit `.teaser`-Karten: Kicker „Essay" in `#2a4b8d`,
  `h2`, Anrisstext, `.teaser-meta` mit Datum und Lesedauer.
- Zwei Platzhalter-Einträge (1. August 2026, 15. Mai 2026).
- Fuß: `.register-footer` mit „Zur Startseite".

Inhalte kommen wie bisher aus den Markdown-Dateien in `essays/`.

---

### 6. Essay — Artikel

Unverändert gegenüber Version 1, einzige Änderung: der `.article-kicker`
„Essay" steht jetzt in `#2a4b8d`.

Aufbau: `article.article` mit `.article-head` (Kicker, `h1`,
`.article-byline` „Von Marc Sandmann · Datum · Lesezeit") und
`.article-body` im Spaltensatz mit Initiale (`.lede` + `.dropcap`),
Zwischentiteln, `blockquote` in der Akzentfarbe. Darunter `.article-footer`
mit `.btn.btn-ghost` „← Zurück zur Übersicht".

---

### 7. Stationen (`stationen.html`) — neue Seite

**Kopf** — `.register-header`: `h1` „Stationen"; Absatz: „Studium,
Redaktion, Beratung, Archiv und ehrenamtliche Arbeit. Die Reihenfolge folgt
den Bereichen, nicht dem Kalender — was ich dort gemacht habe, steht jeweils
daneben." Kennzahlen (`background: #e4e9f4`): „Studium Hamburg",
„Stationen 8".

**Ausbildung** — eigener Block: `background: #e4e9f4`,
`padding: var(--space-8)`, Grid `220px 1fr`, `gap: var(--space-8)`, unten
2px Trennlinie. Links `h6` „Ausbildung". Rechts zwei Einträge
(`gap: var(--space-4)`), je Titel in Heading-Font 800/17px und darunter
`.text-muted` 14px:

1. „Soziologie und Kunstgeschichte (Hauptfächer), Germanistik und Geschichte (Nebenfächer)" — „Universität Hamburg · laufend"
2. „B.A. Wirtschaftspsychologie" — „abgeschlossen"

**Stationsgruppen** — pro Gruppe Grid `220px 1fr`, unten 2px Trennlinie.
Links `h6` mit dem Gruppennamen (`padding: var(--space-8)`, 2px Trennlinie
rechts). Rechts eine **Flex-Spalte** (nicht Grid) mit den Zeilen:
`padding: var(--space-4) var(--space-8)`, Flex,
`justify-content: space-between`, `align-items: baseline`,
`gap: var(--space-6)`. Links der Name (Heading-Font 800/16px), rechts das
Jahr (Heading-Font 800/14px, `#2a4b8d`, rechtsbündig).

Wichtig: Die Trennlinie sitzt als `border-top` auf jeder Zeile **außer der
ersten** — nicht als `border-bottom`. Sonst entsteht bei einzeiligen Gruppen
eine leere, umrandete Geisterzeile und am Gruppenende eine Doppellinie.

| Gruppe | Station | Jahr |
|---|---|---|
| Redaktion und Beratung | Die Zeit (Hamburg) | 2023 |
| | 1789 Consulting (Frankfurt) | 2024 |
| | Aon (Hamburg) | 2024 |
| Wissenschaft und Archiv | Deutsches Literaturarchiv (Marbach) | seit 2026 |
| Organisation und Ehrenamt | Scrum Master | *(offen)* |
| | Betreuung von Freiwilligendiensten | seit 2021 |
| | Vamos Friesoythe (Jugendfahrt) | *(offen)* |
| | Zivildienst in einem psychiatrischen Wohnheim | 2019/20 |

Fuß: `.register-footer` mit `.btn.btn-primary` „Zur Startseite".

---

### 8. Kontakt (`kontakt.html`)

Grid `1.4fr 1fr`, unten 2px Trennlinie.

*Links* (`padding: var(--space-8)`, 2px Trennlinie rechts):

- `h6` „Kontakt" in `#2a4b8d`
- `h1` `clamp(28px, 4vw, 48px)`, `max-width: 16ch` — „Fragen, Hinweise, Anfragen."
- Absatz 16px, `max-width: 52ch`: „Für Rückfragen zu einer Arbeit, einem
  Vortrag oder einem Essay — und ebenso, wenn du über ein gemeinsames
  Projekt, eine Literaturempfehlung oder eine offene Stelle sprechen willst.
  Ich antworte in der Regel innerhalb weniger Tage."
- Zwei Felder (`gap: var(--space-4)`): „E-Mail" mit
  `info.marcsandmann@gmail.com` (Heading-Font 800/17px, Link) und
  „Standort" mit „Hamburg" (`.text-muted` 15px)

*Rechts*: dasselbe Porträtfoto, `min-height: 380px`, `object-fit: cover`,
`object-position: 50% 22%`, **in Farbe**.

Darunter das Kontaktbanner wie auf der Startseite: `h2` „Schreib mir unter"
plus E-Mail-Link.

---

## Interaktionen

Die Seite ist statisch. Es gibt keine Zustände jenseits von Hover und Fokus.

- Alle Hover- und Fokuszustände kommen aus `styles.css` und sollen nicht
  überschrieben werden: Hover-Tönung aus der Akzentrampe, gedrückter Zustand
  eine Stufe dunkler, `:focus-visible` als 2px Akzent-Outline mit 2px
  Offset.
- `.entry`, `.teaser` und `.download-card` sind vollflächige Links.
- Navigation: einfache Seitenwechsel, kein JavaScript.
- Responsive Verhalten ist bereits in `site.css` definiert (Umbrüche bei
  900px und 640px). Neue Layouts sinngemäß ergänzen: die Grids
  `1.5fr 1fr`, `1.6fr 1fr`, `1.4fr 1fr` und `220px 1fr` werden unter 900px
  einspaltig, das vierspaltige Stationsraster wird zweispaltig und unter
  640px einspaltig.

## Design Tokens

Alle Werte außer der Zweitfarbe stammen aus `styles.css` (Designsystem
„Modernist"). Bitte weiterhin ausschließlich die Variablen verwenden.

**Farben**

| Rolle | Wert | Verwendung |
|---|---|---|
| `--color-bg` | `#f3f2f2` | Seitengrund |
| `--color-text` | `#201e1d` | Text |
| `--color-accent` | `#ec3013` | Primärbutton, Kontaktbanner, Zitatmarke |
| `--color-divider` | (aus `styles.css`) | 2px Sektionslinien, 1px Zeilenlinien |
| **Zweitfarbe** | `#2a4b8d` | Rubriken, Fachgruppen-Überschriften, Tags, Jahreszahlen, Spaltenkopf-Linien, Fußzeilenlinie |
| **Zweitfarbe, Tönung** | `#e4e9f4` | Flächen: Biografieblock, Kennzahlenfelder, Gruppenköpfe, Metadatenspalte, Ausbildungsblock, Infokasten |

Die Zweitfarbe ist eine bewusste Erweiterung des Designsystems, das
eigentlich einfarbig rot ist. Rot bleibt den Aktionen vorbehalten
(Buttons, Kontaktbanner), Blau ordnet und gliedert. Diese Rollentrennung
bitte durchhalten.

**Abstände** — nur die vorhandenen Stufen verwenden:
`--space-1`, `-2`, `-3`, `-4`, `-6`, `-8`.
**Achtung: `--space-5` existiert nicht.** Eine Regel mit `var(--space-5)`
fällt komplett aus und setzt das Padding auf 0.

**Typografie** — Archivo für Überschriften und Fließtext
(`--font-heading` / `--font-body`), Überschriften 800.
Größen: `h1` `clamp(28px, 3.6vw, 46px)` (Startseite) bzw.
`clamp(28px, 4vw, 48px)` (Unterseiten), `h3` 20px, Fließtext 15–17px,
Metatext 13–14px.

**Radius** — überall 0. `--radius-md` ist bewusst 0; keine abgerundeten Ecken.

**Schatten** — nur `--shadow-sm/md/lg`. Auf der echten Website trägt nur
`.page-shell` einen Schatten.

## Assets

- `assets/portrait.png` — Porträtfoto (Vortragssituation), vom Autor
  bereitgestellt. Wird auf Startseite und Kontaktseite verwendet,
  **in Farbe**, `object-position: 50% 22%`. Für die Website bitte als
  optimiertes JPEG/WebP in zwei Größen ausliefern.
- Icons: das Designsystem sieht Lucide vor; aktuell werden keine verwendet.

## Dateien in diesem Paket

- `Website-Umsetzung v2.dc.html` — der Prototyp mit allen acht Ansichten
- `styles.css` — Designsystem „Modernist" (unverändert)
- `site.css` — Seitenlayout (unverändert gegenüber dem Repo)
- `newspaper.css` — Essay-Layout (unverändert)
- `support.js` — nur damit der Prototyp lokal im Browser läuft; **nicht** in
  die Website übernehmen
- `assets/portrait.png`

## Offene Punkte

1. Untertitel für 17 der 18 Themen fehlen — Autor liefert nach.
2. Jahreszahlen für „Scrum Master" und „Vamos Friesoythe (Jugendfahrt)" fehlen.
3. Die Fachzuordnung der Arbeiten ist aus den Titeln abgeleitet und noch
   nicht bestätigt.
4. Abstracts und PDFs der Arbeiten liegen noch nicht vor; die Detailseite
   existiert bisher nur als Muster.
5. Essay-Inhalte sind Platzhalter.
